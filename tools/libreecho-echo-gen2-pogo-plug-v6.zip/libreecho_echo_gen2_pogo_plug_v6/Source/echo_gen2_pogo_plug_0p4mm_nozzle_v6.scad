/*
LibreEcho Echo Gen 2 keyed pogo plug, revision 6.
Optimised for slicing with a 0.4 mm FDM nozzle. Print it in a rigid material
(PLA or PETG), wiring face on the bed, no supports.

Why revision 6: only one row of the six base contacts is the USB port. One of
the three unused contacts (TP17, TP19, TP22) is reported to carry the 15 V
supply rail; which one has not been measured. The revision 5 carrier fitted
either way round, so a reversed plug could put that rail on a USB data or
ground wire. Revision 6 has a key: an arm that reaches from the lid to the
nearest rim of the base and ends in a lip that hangs over the rim
(key_style="hook"). Reversed, the lip lands on the base and holds the pins
off the contacts. pin_rows chooses six bores or the USB row only.

Fit: a PLA print of the six-pin plug with these values (hook_drop 12,
ridge_extra 0.2) was fitted to an Echo 2nd Gen on 16 November 2026.

Model axes, seen from the wiring side (looking at the underside of the Echo):
  +y points to the centre of the Echo, -y to its rim and the Amazon logo.
  The USB row is the OUTER row (y = -pitch_y/2).
  Along that row, x = -3, 0, +3 is TP15 (D+), TP14 (D-), TP13 (GND);
  the hook leaves the plug on the TP13 (GND) end of that row.
  The order along the row is read from the AMP board photo in the install
  guide and has NOT been measured: check GND with a multimeter before wiring.
z = 0 is the contact end of the insert; the lid is at the top.

The insert, lead-in and bore geometry are unchanged from revision 5; the
ridges are 0.2 mm bigger.

CLI examples:
  openscad -D 'part="plug_print"' -D 'pin_bore_d=1.0' -o six_pin.stl this_file.scad
  openscad -D 'part="plug_print"' -D 'pin_rows="outer"' -o usb_row.stl this_file.scad
  openscad -D 'part="coupon"' -o coupon.stl this_file.scad
*/

$fn = 96;
part = "plug"; // plug, plug_print (wiring face on the bed), pair_print, coupon, preview

// Which contact rows get bores: "both" (six-pin carrier), "outer" (USB row
// only) or "inner" (TP17/TP19/TP22: measurement only, never for a USB cable).
// Rows without bores stay solid.
pin_rows = "both";

// Plug geometry from measurements (revision 5).
lid_l = 10.0;
lid_w = 7.6;
lid_r = 2.0;
lid_t = 2.0;
body_l = 8.8;
body_w = 6.0;
body_r = 1.8;
insert_depth = 5.0;
lead_in_depth = 0.60;
lead_l = 8.15;
lead_w = 5.35;
lead_r = 1.50;
ridge_l = 9.7;
ridge_w = 6.9;
ridge_h = 0.56;
ridge_centres = [1.10, 2.20, 3.30, 4.35];
ridge_extra = 0.2;    // added to ridge_l and ridge_w. 0.2 is snug in PLA; 0.4 was
                      // too big; 0 (revision 5) was loose.

// 2 x 3 pin pattern.
pitch_x = 3.0;
pitch_y = 3.0;
pogo_barrel_d = 0.66;

// Print-safe bore. Recommended first full plug: 1.0 mm.
pin_bore_d = 1.0;
mouth_extra_d = 0.60;       // 1.60 mm mouth for a 1.00 mm bore.
mouth_depth = 0.70;
wire_pocket_extra_d = 0.80; // Slightly wider top pocket for adhesive.
wire_pocket_depth = 0.65;

// Orientation mark, engraved in the lid on the centre side: an arrow that
// points to the centre of the Echo ("outer"/"inner"), or two dimples on the
// centre side ("both", where the arrow would run into the bores).
mark_depth = 0.50;
mark_arrow_w = 3.4;
mark_arrow_l = 2.0;
mark_dimple_d = 0.75;

// Key. Print a keyed plug in a rigid material (PLA, PETG): in TPU the arm
// bends and lets the plug seat reversed.
key_style = "hook";   // hook, leg (unmeasured, see below), none (fit tests only)

// Key hook (key_style="hook"). An arm reaches from the lid to the nearest rim
// of the base plate and ends in a lip that drops over the rim. The right way
// round the lip hangs outside the rim and the plug seats; reversed, the lip
// lands on the base plate and holds the plug up by at least hook_drop.
// The cap over the lid has a slot above each row of bores, so bore length and
// the adhesive pockets are as in revision 5.
// Test piece 1 (15 November 2026, PLA, hook_rim_gap 15.7, hook_clearance 1.5)
// seated with the lip 2 to 3 mm outside the rim, so the rim is taken as 14.7.
// Direction and plate radius are photo estimates that fitted.
// Test plate 2 (arm on top of the lid, 2 mm above the surface, lip 4 mm): the
// reversed plug could still be worked in at a steep tilt. The lid rests on
// the surface, so the arm now runs 0.2 above it and the lip is longer.
// Test plate 3 (lip 8 and 12 mm): the 12 mm lip was chosen.
hook_dir_deg = 330;    // from the plug centre to the nearest rim, anticlockwise
                       // from +x seen from the wiring side (0 = along the row
                       // toward TP13, 270 = straight to the rim side).
hook_rim_gap = 14.7;   // plug centre to the outside of the rim.
plate_r = 40.0;        // radius of the base plate (lip curvature only).
hook_clearance = 1.0;  // gap between rim and lip.
hook_lip_t = 3.0;      // lip thickness, radial.
hook_lip_w = 10.0;     // lip width along the rim.
hook_drop = 12.0;      // lip end below the lid underside.
hook_arm_lift = 0.2;   // arm underside above the lid underside (lid_t = arm
                       // on top of the lid, clear of the surface).
hook_arm_t = 2.8;      // arm thickness; what stands above the lid top is the cap.
hook_arm_floor = hook_arm_lift; // underside of the arm beyond the lid, above the
                       // lid underside. Lower than hook_arm_lift makes the arm
                       // deeper and stiffer (needed in TPU); it must stay
                       // clear of the surface between the opening and the rim.
cap_slot_w = 2.6;      // wiring slot in the cap above a row of bores.
variant_dots = 0;      // dimples on the arm, to tell test variants apart.

// Key leg (key_style="leg"). A tab grows out of the lid and carries a leg that drops below the
// lid underside into a feature of the Echo's underside (a screw recess, or
// over a step). The right way round the leg finds the feature and the plug
// seats; reversed, the leg lands on plain plastic and holds the plug up.
// ALL THREE POSITION VALUES BELOW ARE PLACEHOLDERS UNTIL MEASURED ON A DEVICE.
// Photo estimate only (no ruler, +-1 mm): the Torx screw recess below the
// contacts is at key_dir_deg = 258, key_reach = 13.9, about 6.3 mm across;
// its depth is unknown.
key_dir_deg = 270;    // tab direction from the plug centre, anticlockwise
                      // from +x seen from the wiring side; 270 = to the rim.
key_reach = 0;        // plug centre to leg centre.                  [MEASURE]
key_leg_drop = 0;     // leg end below the lid underside when seated [MEASURE]
key_leg_l = 3.0;      // leg size along the tab direction.           [MEASURE]
key_leg_w = 3.0;      // leg size across the tab direction.          [MEASURE]
key_leg_r = 1.2;      // leg corner radius (key_leg_l/2 gives a round post).
key_tab_w = 4.0;      // tab width where it leaves the lid.
// How far the relaxed pogo tips stand below the insert face. A reversed plug
// is held up by hook_drop or key_leg_drop, which must exceed this by
// key_safety_margin so that no pin can reach a contact.
pin_protrusion = 2.0;
key_safety_margin = 1.0;

// Fit-test plate (part="pair_print"): two variants side by side, told apart
// by one and two dimples on the arm.
pair_ridge_extra = [0.2, 0.2];   // ridge_extra of each piece
pair_hook_drop = [8.0, 12.0];    // and its hook_drop
pair_spacing = 24;

coupon_bores = [0.80, 0.90, 1.00, 1.10, 1.20];

function xpos(i) = (i - 1) * pitch_x;
function ypos(j) = (j - 0.5) * pitch_y;   // j = 0 outer row, j = 1 inner row
function row_used(j) =
    pin_rows == "both" || (pin_rows == "outer" && j == 0)
                       || (pin_rows == "inner" && j == 1);

function plug_top_h() = key_style == "hook"
    ? max(insert_depth+lid_t,insert_depth+hook_arm_lift+hook_arm_t)
    : insert_depth + lid_t;

module rr2d(l, w, r) {
    offset(r=r) square([l - 2*r, w - 2*r], center=true);
}

module rr_prism(l, w, r, h, z=0) {
    translate([0,0,z]) linear_extrude(height=h) rr2d(l,w,r);
}

module rr_loft(l0,w0,r0,z0,l1,w1,r1,z1) {
    hull() {
        translate([0,0,z0]) linear_extrude(height=0.01) rr2d(l0,w0,r0);
        translate([0,0,z1-0.01]) linear_extrude(height=0.01) rr2d(l1,w1,r1);
    }
}

module key_leg2d() {
    rotate(key_dir_deg) translate([key_reach,0])
        rr2d(key_leg_l,key_leg_w,min(key_leg_r,key_leg_l/2-0.01,key_leg_w/2-0.01));
}

module key_leg() {
    // Tab, level with the lid.
    translate([0,0,insert_depth]) linear_extrude(height=lid_t) hull() {
        rotate(key_dir_deg) translate([0,-key_tab_w/2]) square([0.01,key_tab_w]);
        key_leg2d();
    }
    // Leg, from the lid underside downwards.
    translate([0,0,insert_depth-key_leg_drop])
        linear_extrude(height=key_leg_drop+0.01) key_leg2d();
}

// Lip footprint: a piece of a ring around the base plate centre.
module hook_lip2d() {
    r_in = plate_r + hook_clearance;
    rotate(hook_dir_deg) intersection() {
        translate([hook_rim_gap - plate_r,0]) difference() {
            circle(r=r_in + hook_lip_t, $fn=360);
            circle(r=r_in, $fn=360);
        }
        translate([hook_rim_gap,-hook_lip_w/2])
            square([hook_clearance + hook_lip_t + 1,hook_lip_w]);
    }
}

module key_hook(drop=hook_drop) {
    z_arm = insert_depth + hook_arm_lift;
    z_floor = insert_depth + hook_arm_floor;
    // Arm and cap; beyond the lid the arm reaches down to z_floor.
    translate([0,0,z_floor]) linear_extrude(height=z_arm-z_floor+hook_arm_t) hull() {
        rr2d(lid_l,lid_w,lid_r);
        hook_lip2d();
    }
    // Lip, from the arm downwards.
    translate([0,0,insert_depth-drop])
        linear_extrude(height=drop+hook_arm_lift+0.01) hook_lip2d();
}

// Dimples in the top of the arm, in a row across it.
module variant_marks(dots,top_h) {
    for (k=[0:1:dots-1])
        rotate(hook_dir_deg) translate([hook_rim_gap-4.5,(k-(dots-1)/2)*2.4,top_h-mark_depth])
            cylinder(h=mark_depth+0.05,d=1.4);
}

// Slots through the cap, above the rows that have bores.
module cap_slots() {
    z0 = insert_depth + lid_t;
    for (j=[0:1]) if (row_used(j))
        translate([0,ypos(j),z0-0.01]) linear_extrude(height=hook_arm_lift+hook_arm_t+1)
            rr2d(2*pitch_x+cap_slot_w,cap_slot_w,cap_slot_w/2-0.01);
}

module raw_plug(rx=ridge_extra,drop=hook_drop) {
    union() {
        rr_loft(lead_l,lead_w,lead_r,0,
                body_l,body_w,body_r,lead_in_depth);
        rr_prism(body_l,body_w,body_r,insert_depth-lead_in_depth,lead_in_depth);

        for (zc=ridge_centres)
            if (zc-ridge_h/2 > 0 && zc+ridge_h/2 < insert_depth) {
                rl = ridge_l + rx;
                rw = ridge_w + rx;
                local_r = min(body_r+(rl-body_l)/2,
                              body_r+(rw-body_w)/2);
                rr_loft(body_l,body_w,body_r,zc-ridge_h/2,
                        rl,rw,local_r,zc);
                rr_loft(rl,rw,local_r,zc,
                        body_l,body_w,body_r,zc+ridge_h/2);
            }

        rr_prism(lid_l,lid_w,lid_r,lid_t,insert_depth);

        if (key_style == "leg") key_leg();
        if (key_style == "hook") key_hook(drop);
    }
}

module print_safe_hole(x,y,bore=pin_bore_d,total_h=insert_depth+lid_t) {
    mouth_d = bore + mouth_extra_d;
    pocket_d = bore + wire_pocket_extra_d;

    // Straight through-channel.
    translate([x,y,-0.25]) cylinder(h=total_h+0.50,d=bore);

    // Contact-side flared mouth. This is the body end at z=0.
    translate([x,y,-0.01])
        cylinder(h=mouth_depth+0.02,d1=mouth_d,d2=bore);

    // Wiring-side adhesive pocket, at the outside face of the lid.
    translate([x,y,total_h-wire_pocket_depth])
        cylinder(h=wire_pocket_depth+0.02,d1=bore,d2=pocket_d);
}

module orientation_mark(total_h) {
    translate([0,0,total_h-mark_depth]) linear_extrude(height=mark_depth+0.05) {
        if (pin_rows == "both") {
            for (x=[-pitch_x/2,pitch_x/2])
                translate([x,lid_w/2-0.8]) circle(d=mark_dimple_d);
        } else {
            // Arrow in the solid half of the lid; it always points to +y.
            yc = (pin_rows == "outer" ? 1 : -1) * (lid_w/4 + 0.15);
            translate([0,yc])
                polygon([[-mark_arrow_w/2,-mark_arrow_l/2],
                         [ mark_arrow_w/2,-mark_arrow_l/2],
                         [0,mark_arrow_l/2]]);
        }
    }
}

module plug(bore=pin_bore_d,rx=ridge_extra,dots=variant_dots,drop=hook_drop) {
    total_h = insert_depth + lid_t;
    top_h = plug_top_h();
    assert(pin_rows == "outer" || pin_rows == "inner" || pin_rows == "both",
           str("Unknown pin_rows: ",pin_rows));
    assert(key_style == "none" || key_style == "leg" || key_style == "hook",
           str("Unknown key_style: ",key_style));
    if (key_style == "hook") {
        assert(drop >= pin_protrusion + key_safety_margin,
               "hook_drop too small: a reversed plug could still touch the contacts");
        // Reversed, the whole lip must land on the plate, not beyond its far rim.
        assert(hook_rim_gap + hook_clearance + hook_lip_t < 2*plate_r - hook_rim_gap - 2,
               "reversed lip would miss the base plate");
        assert(hook_arm_lift >= 0 && hook_arm_lift + hook_arm_t >= lid_t,
               "arm top must not be below the lid top (the plug prints top face down)");
        assert(hook_arm_floor >= 0 && hook_arm_floor <= hook_arm_lift,
               "hook_arm_floor must be between 0 and hook_arm_lift");
    } else if (key_style == "leg") {
        assert(key_reach > 0 && key_leg_drop > 0,
               "key_style=\"leg\" needs measured key_reach and key_leg_drop");
        assert(key_leg_drop >= pin_protrusion + key_safety_margin,
               "key_leg_drop too small: a reversed plug could still touch the contacts");
    } else {
        echo("WARNING: key_style=\"none\": this plug is NOT keyed and fits either way round. Fit tests only.");
    }
    difference() {
        raw_plug(rx,drop);
        for (i=[0:2]) for (j=[0:1]) if (row_used(j))
            print_safe_hole(xpos(i),ypos(j),bore,total_h);
        if (key_style == "hook") cap_slots();
        if (key_style == "hook" && dots > 0) variant_marks(dots,top_h);
        // On a six-pin hook plug the hook itself is the mark.
        if (!(key_style == "hook" && pin_rows == "both")) orientation_mark(top_h);
    }
}

// Five-hole flared-bore coupon, left to right: 0.8, 0.9, 1.0, 1.1, 1.2 mm.
module coupon() {
    coupon_l = 34.0;
    coupon_w = 10.0;
    coupon_t = 3.2;
    xvals = [-12,-6,0,6,12];
    difference() {
        rr_prism(coupon_l,coupon_w,1.5,coupon_t,0);
        for (k=[0:4]) {
            bore = coupon_bores[k];
            x = xvals[k];
            // Through bore plus 0.6 mm flare at both faces.
            translate([x,0,-0.2]) cylinder(h=coupon_t+0.4,d=bore);
            translate([x,0,-0.01])
                cylinder(h=0.62,d1=bore+0.60,d2=bore);
            translate([x,0,coupon_t-0.60])
                cylinder(h=0.62,d1=bore,d2=bore+0.60);
        }
    }
    // Raised labels are intentionally large enough for a 0.4 mm nozzle.
    labels = ["0.8","0.9","1.0","1.1","1.2"];
    for (k=[0:4])
        translate([xvals[k],-3.1,coupon_t])
            linear_extrude(height=0.45)
                text(labels[k],size=1.65,halign="center",valign="center",
                     font="Liberation Sans:style=Bold");
}

module pogo_visual(x,y) {
    color([0.78,0.57,0.12]) {
        translate([x,y,-pin_protrusion]) cylinder(h=7.5+pin_protrusion,d=pogo_barrel_d);
        translate([x,y,-pin_protrusion]) sphere(d=0.72);
        translate([x,y,7.4]) cylinder(h=5.0,d=0.48);
    }
}

module preview() {
    color([0.12,0.37,0.56]) plug(pin_bore_d);
    for (i=[0:2]) for (j=[0:1]) if (row_used(j)) pogo_visual(xpos(i),ypos(j));
}

if (part == "plug") plug(pin_bore_d);
else if (part == "plug_print")
    translate([0,0,plug_top_h()]) rotate([180,0,0]) plug(pin_bore_d);
else if (part == "pair_print") {
    // Two test variants on one plate: one dimple = first entry, two = second.
    for (k=[0:1]) translate([0,k*pair_spacing,plug_top_h()]) rotate([180,0,0])
        plug(pin_bore_d,pair_ridge_extra[k],k+1,pair_hook_drop[k]);
}
else if (part == "coupon") coupon();
else if (part == "preview") preview();
else assert(false,str("Unknown part: ",part));
