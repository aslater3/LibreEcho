# LibreEcho Echo Gen 2 pogo plug — v6 (keyed)

3D-printable carrier for the six pogo pins that reach the gold contacts in the
base of the Echo 2nd Gen. It replaces v5. The part that goes into the contact
opening is the same as v5; v6 adds a key so the plug can only be seated one way
round, and slightly bigger retention ridges.

## Why it is keyed

Only three of the six contacts are used: D+, D− and GND, all in one row. The
other three (TP17, TP19, TP22) are not used, and one of them is reported to
carry the 15 V supply rail (which one has not been measured). v5 fits either
way round, so it can put the USB wires on that other row.

v6 has an arm that runs to the nearest edge of the base and a lip that hangs
12 mm down over that edge. Turned round, the lip lands on the base plate and
the pins cannot reach the contacts.

## Pin-out

![Pin-out of the seated plug](echo-gen2-pogo-plug-v6-pinout.svg)

Look at the wiring side of the seated plug, with the key arm pointing to the
lower right, as in the drawing:

| Position | Signal | Board pad | USB cable wire |
|---|---|---|---|
| Row nearer the edge of the base, pin nearest the key arm | GND | TP13 | black |
| Same row, middle pin | D− | TP14 | white |
| Same row, pin furthest from the key arm | D+ | TP15 | green |
| Row nearer the centre of the Echo, all three | not used | TP17, TP19, TP22 | none |

- Connect only D+, D− and GND. Leave the cable's red 5 V wire unconnected; the
  Echo runs from its own power adapter.
- Connect nothing to the other three pins. The six-pin models have bores for
  them only so that later uses are possible; you can leave those bores empty.
  The `usb_row` model has bores for the three USB pins only.
- The order along the row is taken from the AMP board photo in the install
  guide (`docs/install/assets/usb-dplus-dminus-gnd.jpg`). It has not been
  measured on a device. Before first use, check with a multimeter that the pin
  nearest the key arm is ground: with the Echo unplugged from power, it should
  show continuity to a ground point of the Echo, for example the sleeve
  contact of the 3.5 mm audio socket.

## Printing

- Rigid material: PLA or PETG. The key relies on a stiff arm; this geometry is
  not suitable for TPU.
- 0.4 mm nozzle, 0.2 mm layers, no supports. The STLs are already in the print
  pose: wiring face on the bed, insert and lip pointing up.
- Print the bore coupon first if you are unsure of your printer. The 1.00 mm
  bore is the recommended start for a pogo pin with a barrel of about 0.66 mm.
- Retain the pins at the wiring-side pocket with a very small amount of epoxy
  or UV resin, kept away from the moving plunger. The wires leave through the
  two slots in the top of the plug.

## Using it

Remove only the outer cover on the base of the Echo. Push the plug into the
contact opening with the arm pointing to the nearest edge of the base, so the
lip drops over the edge. The plug must stay seated without being held: secure
it with a band or clamp before you power on.

## Files

| File | Content |
|---|---|
| `STL/echo_gen2_pogo_plug_v6_keyed_six_pin_bore0p80.stl` to `…bore1p20.stl` | keyed plug, six bores, bore 0.80 to 1.20 mm |
| `STL/echo_gen2_pogo_plug_v6_keyed_usb_row_bore1p00.stl` | keyed plug, bores for the three USB pins only, bore 1.00 mm |
| `STL/echo_gen2_pogo_flared_bore_coupon_0p8_to_1p2.stl` | bore calibration coupon (unchanged from v5) |
| `Source/echo_gen2_pogo_plug_0p4mm_nozzle_v6.scad` | parametric OpenSCAD source |
| `echo-gen2-pogo-plug-v6-pinout.svg` | the pin-out drawing above |
| `SHA256SUMS.txt` | checksums of the files above |

STLs are binary, 24-segment tessellation, as for v5.

## Geometry

- insert as v5: body 8.8 × 6.0 mm, 5.0 mm deep, 2 × 3 pins on a 3.0 mm pitch,
  flared bores for a 0.4 mm nozzle
- retention ridges 9.9 × 7.1 mm (v5: 9.7 × 6.9 mm)
- lid 10.0 × 7.6 mm; lid, cap and arm together stand 3.0 mm above the base
- key: arm at 330° from the row direction, lip 10 mm wide and 3 mm thick,
  hanging 12 mm below the underside of the lid, 14.7 mm from the centre of the
  contact opening to the edge of the base, 1.0 mm clearance

## What has been checked

- Fit: a PLA print of the six-pin, 1.00 mm bore model was fitted to one Echo
  2nd Gen on 16 November 2026. It seats the right way round and holds.
- Not yet checked: the pin order by measurement (see above), which contact
  carries 15 V, a USB connection made through a v6 print, and fit with the
  fabric shell on.
