# LibreEcho Echo Gen 2 pogo plug — v5

3D-printable replacement carrier for the six pogo pins exposed through the Echo 2nd Gen base/service plug.

Measured/design geometry:

- rounded-rectangle plug
- 2 × 3 pogo layout on 3.0 mm pitch
- measured pogo barrel diameter: approximately 0.66 mm
- 10.0 × 7.6 mm clearance lid
- 8.8 × 6.0 mm insert body
- 5.0 mm insert depth below the 2.0 mm lid
- flared through-bores intended to slice reliably with a 0.4 mm FDM nozzle

The package contains 0.80, 0.90, 1.00, 1.10 and 1.20 mm central-bore plug variants, a calibration coupon, and the parametric OpenSCAD source.

For a 0.4 mm nozzle, print the calibration coupon first. The 1.00 mm model is the recommended initial carrier for a measured 0.66 mm pogo barrel. Retain the pins at the wiring-side pocket with a very small amount of epoxy or UV resin, kept away from the moving pogo plunger.

The repository package uses binary STL encoding and 24-segment tessellation. That is substantially finer than the useful resolution of a 0.4 mm nozzle while avoiding unnecessary Git repository bloat; the v5 model dimensions and feature geometry are unchanged.
